<?php 
error_reporting(E_ALL);

$s = simplexml_load_file('newSms.xml');

foreach ($s->sms as $sms) {
echo '<div class="textmessage">' . "\n" . '<h3>' . "\n";
echo $sms->number;
echo '</h3>' . "\n" . '<h4>' . "\n";
echo $sms->time;
echo '</h4>' . "\n" . '<p>' . "\n";
echo $sms->message;
echo '</p>' . "\n" . '</div>' . "\n";
}


?>