<?php 
error_reporting(E_ALL);


if (isset($_GET['delete'])) {
	// User wants to delete a contact.
	
	$name = isset($_GET['delete']);
	
	$xml = simplexml_load_file('contacts.xml');
	foreach ($xml->contact as $contact) {
		if ($contact->name == $name) {
			// This is the correct XML node to delete
			$node = dom_import_simplexml($contact);
    		$node->parentNode->removeChild($node);
			
			$doc = new DOMDocument('1.0');
			$doc->formatOutput = true;
			$doc->loadXML($xml->asXML());
			$doc->save('contacts.xml');
			//print_r($xml);
		}
	}

}

/*
 *	Adding new contact
 */
 
if (isset($_POST['name'])&&isset($_POST['number'])) {
	$xml = simplexml_load_file('contacts.xml');
	
	$name = $_POST['name'];
	$number = $_POST['number'];
	
	$newcontact = $xml->addChild("contact");
	$newcontact->addChild($name);
	$newcontact->addChild($number);

	$doc = new DOMDocument('1.0');
	$doc->formatOutput = true;
	$doc->loadXML($xml->asXML());
	
	$doc->save('contacts.xml');

}


$s = simplexml_load_file('contacts.xml');

foreach ($s->contact as $contact) {
	echo '<div class="contact">' . "\n" . '<h3>' . "\n";
	echo $contact->name;
	echo '</h3>' . "\n" . '<h4>' . "\n";
	echo $contact->number;
	echo '</h4>' . "\n" . '</div>' . "\n";
	echo '<a id ="delete" href="contacts.php?delete=' . $contact->name . '">delete</a>';
}


?>

<form name="sms" action="contacts.php" method="post">
	Name :<input type="text" name="name">
	Number :<input type="tel" name="number">
	<input type="submit" value="Submit">
</form>